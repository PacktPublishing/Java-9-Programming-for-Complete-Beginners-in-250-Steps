package com.in28minutes.firstjavaproject;

public class HelloWorld {

	public static void main(String[] args) {
		
	}

}